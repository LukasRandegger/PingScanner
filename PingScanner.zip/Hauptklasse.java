/**
 * Hauptklasse
 */

public class Hauptklasse {
    public static Gui gui;

    public static void main(String[] args) throws Exception {
        gui = new Gui();
    }
}