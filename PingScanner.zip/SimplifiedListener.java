// import java.awt.*;
// import javax.swing.*;
import java.awt.event.*;

/**
 * Klasse für vereinfachte Tasteneingabe und J-Element-Aktionsabfragen
 */
public class SimplifiedListener implements KeyListener, ActionListener
{
    //  Methode aus KeyListener
    @Override
    public void keyPressed(KeyEvent e) {
    }
    
    //  Methode aus KeyListener
    @Override
    public void keyReleased(KeyEvent e) {
    }
    
    //  Methode aus KeyListener
    @Override
    public void keyTyped(KeyEvent e) {
    }

    //  Methode aus ActionListener
    @Override
    public void actionPerformed(ActionEvent e) {
    }
}