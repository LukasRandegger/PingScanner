/**
 * Host
 */
public class Host {

    String ip_adresse;
    String host_name;

    public Host(String ip, String host){
        this.host_name = host;
        this.ip_adresse = ip;
    }
}